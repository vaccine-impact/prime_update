## ----setup, include = FALSE---------------------------------------------------
# load package - prime
library(prime)

## ----eval=FALSE---------------------------------------------------------------
#  
#  # View documentation of RunCohort function
#  ?RunCohort
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  # View source code of RunCohort function
#  RunCohort
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  # View documentation of data.incidence data set
#  ?data.incidence
#  

## ----eval=FALSE---------------------------------------------------------------
#  
#  # View data set for age-specific incidence of cervical cancer in different countries (estimated by Globocan)
#  data.incidence
#  

## -----------------------------------------------------------------------------
RunCountry ("RWA")

## -----------------------------------------------------------------------------
result <- RunCountry ("RWA")
result [,c("vaccinated", "immunized", "inc.cecx", "mort.cecx", "lifey","disability", "cost.cecx")] <- result[, cohort_size] * result[,c("vaccinated", "immunized", "inc.cecx", "mort.cecx", "lifey", "disability", "cost.cecx")]
result [age>15]

## -----------------------------------------------------------------------------
getISO3 ("Malawi")

## -----------------------------------------------------------------------------
# To be updated
# RunCountry ("MWI", analyseCosts=TRUE)

## -----------------------------------------------------------------------------
# To be updated
# RunCountry("MWI", analyseCosts=TRUE, discounting=TRUE, agevac=10, agecohort=10, vaceff_beforesexdebut=0.98, vaceff_aftersexdebut=0, cov=0.75, year_vac=2020)

## -----------------------------------------------------------------------------
# To be updated
# analyseCosts (
#   RunCountry("MWI", analyseCosts=FALSE, discounting=TRUE, agevac=10, agecohort=10, vaceff_beforesexdebut=0.98, vaceff_aftersexdebut=0, cov=0.75, year_vac=2020),
#   vaccine_cost=100,
#   gdp_per_capita=561
# )

## -----------------------------------------------------------------------------
qx <- unlist(data.mortall[iso3=="MWI", as.character(0:100), with=F], use.names=F)
lifeTable(qx)

## -----------------------------------------------------------------------------
ages <- c(0:100)
routine_coverage <- 0.75
vaccine_efficacy_nosexdebut <- 0.99
vaccine_efficacy_sexdebut <- 0
lifetab <- lifeTable(unlist(data.mortall[iso3=="MWI", as.character(0:100), with=F], use.names=F), 9)
cohort <- unlist(data.popproj[iso3=="MWI", "2020"], use.names=F)
agevac <- 9
ageCoverage(ages, routine_coverage, vaccine_efficacy_nosexdebut=1, vaccine_efficacy_sexdebut=0, -1, lifetab, cohort, agevac, country_iso3="MWI")

## -----------------------------------------------------------------------------
result <- RunCountry ("MWI", analyseCosts=FALSE, discounting=TRUE, agevac=10, agecohort=10, vaceff_beforesexdebut=0.98, vaceff_aftersexdebut=0, cov=0.75, year_vac=2020)

result [,c("vaccinated", "immunized", "inc.cecx", "mort.cecx", "lifey", "disability", "cost.cecx")] <- result [, cohort_size] * result[,c("vaccinated", "immunized", "inc.cecx", "mort.cecx", "lifey", "disability", "cost.cecx")]

# aggregate results on age
result <- dtAggregate (result, "age", id.vars=c("scenario", "type") )
result

