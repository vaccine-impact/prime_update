## ----setup, include = FALSE---------------------------------------------------
# load packages
library (prime)
library (data.table)

## ---- include = FALSE---------------------------------------------------------
#create_dummy_table
batch_input <- data.table(
  country_code = c("MWI", "MWI", "MWI"),
  year = c(2020, 2021, 2022),
  age_first = c(9, 9, 9),
  age_last = c(9, 9, 9),
  coverage = c(0.6, 0.7, 0.8)
)

## -----------------------------------------------------------------------------
batch_input

## -----------------------------------------------------------------------------
RegisterBatchData (batch_input)

## -----------------------------------------------------------------------------
# When overwriting an existing table
RegisterBatchData (batch_input, force=TRUE)

## -----------------------------------------------------------------------------
output <- BatchRun ()

## -----------------------------------------------------------------------------
output

## -----------------------------------------------------------------------------
BatchRun (by_calendaryear=TRUE)

## -----------------------------------------------------------------------------
BatchRun (use_proportions=FALSE)

## ---- include = FALSE---------------------------------------------------------
#create_dummy_table
batch_input <- data.table(
  country_code = c("MWI", "MWI", "MWI"),
  year = c(2020, 2021, 2022),
  age_first = c(9, 9, 9),
  age_last = c(14, 9, 9),
  coverage = c(0.6, 0.7, 0.8)
)

## -----------------------------------------------------------------------------
batch_input

## ---- include = FALSE---------------------------------------------------------
#create_dummy_table
batch_input <- data.table(
  country_code = c("MWI", "MWI", "MWI"),
  year = c(2020, 2020, 2021, 2022),
  age_first = c(9, 10, 9, 9),
  age_last = c(9, 14, 9, 9),
  coverage = c(0.6, 0,75, 0.7, 0.8)
)

## -----------------------------------------------------------------------------
batch_input

